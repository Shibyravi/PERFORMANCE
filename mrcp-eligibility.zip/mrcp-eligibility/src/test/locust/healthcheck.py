import time
from os.path import expanduser
from locust import HttpLocust, TaskSet, events, task
from aadk.aadk import Adjudication

sHome = expanduser("~")
lJob = 0
sWWW = "http://timbrado.uhc.com:8080"
sOp = "beta"
bAlive = True

def loadConfig( sCfgFile=".bluejayrc"):
	global lJob
	global sWWW
	global sOp
	fCfg = open( sHome+"/"+sCfgFile, "r")
	for sLine in fCfg:
		pOpt = sLine.split( "=", 1)
		sKey = pOpt[0].rstrip()
		if sKey == "bluejay.healthcheck."+str(lJob)+".url":
			sWWW = pOpt[1].lstrip().rstrip()
		elif sKey == "bluejay.healthcheck."+str(lJob)+".op":
			sOp = pOpt[1].lstrip().rstrip()

def on_quitting():
	bAlive = False

events.quitting += on_quitting

class TestPlan( TaskSet):
	@task
	def default_task( self):
		global pRTM
		global bAlive
		global sOp
		while bAlive:
			bAlive = False
			pRsp = self.client.get( "/timbrado/portal?op="+sOp)
			pReq = pRsp.request
			sReq = pReq.method+' '+pReq.url+str('\n'.join('{}: {}'.format(k, v) for k, v in pReq.headers.items()))+str(pReq.body)
			iErr = int(pRsp.status_code)
			pAdj = Adjudication()
			pAdj.add("avgrsp",{"max":18,"count":1})
			pAdj.adjudicate()
			time.sleep(2.0)

class vUser( HttpLocust):
	global sWWW
	host = sWWW
	task_set = TestPlan
	min_wait = 500
	max_wait = 5000
