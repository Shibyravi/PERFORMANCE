# BLUEJAY Example

BLUEJAY leverages the Optum GitHub Enterprise service to access tenant repositories for testing artifacts.

[Please see here for details ...](https://github.optum.com/bluejay/support/wiki/OperationManual#22-repository-directory-structure)

